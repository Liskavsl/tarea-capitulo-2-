from machine import Pin
import time

print("Esperando pulsador...")

sw = Pin(23, Pin.IN)
led = Pin(2, Pin.OUT)

contador = 0
while True:
    if sw.value():
        led.value(not led.value())
        contador += 1
        print(contador)
        if contador == 10:
            led.value(not led.value())  # Cambiar el estado del LED
            contador = 0  # Reiniciar el contador
            print("Estado del LED cambiado")

    time.sleep_ms(150)
